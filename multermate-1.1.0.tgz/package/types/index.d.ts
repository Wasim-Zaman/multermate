import { NextFunction, Request, Response } from 'express';
export interface UploadSingleOptions {
    destination?: string;
    filename?: string;
    fileTypes?: string[];
    customMimeTypes?: string[];
    fileSizeLimit?: number;
    preservePath?: boolean;
}
export interface FieldConfig {
    name: string;
    maxCount?: number;
    fileTypes?: string[];
    fileSizeLimit?: number;
}
export interface UploadMultipleOptions {
    fields: FieldConfig[];
    destination?: string;
    customMimeTypes?: string[];
    fileSizeLimit?: number;
    preservePath?: boolean;
}
/**
 * Function to handle a single file upload.
 *
 * @param options - Configuration options for the single file upload.
 * @returns Multer middleware configured for single file upload.
 */
export declare function uploadSingle(options?: UploadSingleOptions): (req: Request, res: Response, next: NextFunction) => void;
/**
 * Function to handle multiple file uploads across multiple fields.
 *
 * @param options - Configuration options for multiple file uploads.
 * @returns Multer middleware configured for multiple file uploads.
 */
export declare function uploadMultiple(options: UploadMultipleOptions): (req: Request, res: Response, next: NextFunction) => void;
/**
 * Utility function to delete a file from the filesystem
 *
 * @param filePath - The path to the file that needs to be deleted
 * @returns Promise that resolves to true if deletion was successful, false otherwise
 */
export declare function deleteFile(filePath: string): Promise<boolean>;
declare global {
    namespace Express {
        interface Request {
            fileValidationError?: string;
        }
    }
}
export declare const ALLOWED_FILE_TYPES: string[];
declare const _default: {
    uploadSingle: typeof uploadSingle;
    uploadMultiple: typeof uploadMultiple;
    deleteFile: typeof deleteFile;
    ALLOWED_FILE_TYPES: string[];
};
export default _default;
